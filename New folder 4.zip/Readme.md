## Dataset Overview
##### The data set contain a large value of trip which is 183,412. Looking at the common features in the data, we will find that there is a correlation between trips, stations, and varying ages. that what we will discuss in the following points.
##### There are 183,412 bike trip in the dataset with 16 features (start_time,end_time,start_station_id,start_station_name,start_station_latitude,start_station_longitude,end_station_id,end_station_name, end_station_latitude,end_station_longitude,bike_id,user_type,member_birth_year,member_gender,bike_share_for_all_trip), thats before adding another 2 featuers. Most variables are numeric in nature, noting that out of 18 specifications 9 are numerical, 2 are datetime, 4 are object type and 1 has been converted to a boolean type.

## Summary Of Findings 

##### I found the proportion of males is significantly higher than the other genders and top 10 charts Market Street, and Caltrain Station San Francisco are the highest starting and destination stations, additionally I looked at it in log transformation due to lots of trip duration takes a large amount of values, and it's fixed on the tail,and found that the peak occurs then the distribution starts to drop and nothing recovers any more of the peak value.
##### Then I got a look at  the correlation gender and type of the user we can say that most of the subscipers are males, also the trips duration for some stations as start station is higher, also, for some stations as end station is higher. so, what is the stations result in starting of longer trips and what stations comes end of longer trips.
##### As i thought quantity of young riders are very high than the older, the mentioned chart proof that higher percentage of younger share most of the trip, morover higher number of customers are taking longer trips then compared to subscribers.
##### As observed subscribers percentage is higher than customers regardeless of the gender, and young ages between 20 ~ 40 dominate all data, and average customers age is 34 years old and subscribers are 36 years old, also the younger gender avrage is females.

## Key Insights For Presentation

### For the presentation i focus on:
##### What is effects of the trip duration generally.
##### The correlation of the users considering the age of them.
##### Distribution Upon The Trip Durations.
##### Correlation Between Trip Durations And Age.
##### The duration reliance on the gender and the member type.
##### Top Ten (Start-End) Stations.
