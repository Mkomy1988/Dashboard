#!/usr/bin/env python
# coding: utf-8

# TMDB-movies Data Analyses

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


df = pd.read_csv('tmdb-movies.csv')
df.shape


# In[3]:


df.head(300)


# In[4]:


df.describe()


# In[5]:


df.info()


# The below columns has been deleted due to will no need to it nor will be useful in my analyse.

# In[6]:


df.drop(['homepage', 'tagline', 'overview', 'id', 'cast', 'keywords'], axis=1, inplace =True)


# In[7]:


round(df['budget'].mean())


# I did Fill full the 0 values in the budget column with the mean of the budget.

# In[8]:


df['budget'] = df['budget'].replace(0, 14625701)


# In[9]:


round(df['revenue'].mean())


# I did fill full the 0 values in the revenue column with the mean of the revenue.

# In[11]:


df['revenue'] = df['revenue'].replace(0, 39823320)


# In[12]:


df.fillna(df.mean(), inplace=True)
df.info()


# In[13]:


df.dropna(inplace=True)
df.head(300)


# In[14]:


df.info()


# In[15]:


a_series = (df != 0).any()
a_series


# In this analyse will check if there is any corelation between the revinew and the budget in, 
# another words if the good movie should have a good budget. additionally, the reason of What makes a movie sucess, 
# also, Is there a difference in films between one era and another.

# In[16]:


df.hist(figsize=(10,8));


# In[17]:


budget =df.budget == True
revenue = df.budget == False


# In[18]:


round(df['budget'].mean())


# In[19]:


round(df['revenue'].mean())


# In[20]:


df.groupby('release_year').revenue.mean().plot(kind='line',fontsize=9, figsize=(8,4), label='revenue')
df.groupby('release_year').budget.mean().plot(kind='line',fontsize=9, figsize=(8,4), label='budget')
plt.legend();
plt.title("Avrage revenue & budget from 1960 to 2015",fontsize=20)
plt.xlabel("release_year")
plt.ylabel("budget & revenue");


# In[21]:


df.plot(x='budget', y='popularity', kind='scatter',label='budget-vs-popularity')
plt.title("co-relation between budget-&-popularity",fontsize=16)
plt.xlabel("budget")
plt.ylabel("popularity");
df.plot(x='release_year', y='popularity', kind='scatter',label='release_year-vs-popularity')
plt.title("co-relation between release_year-&-popularity",fontsize=16)
plt.xlabel("release_year")
plt.ylabel("popularity");


# In[22]:


df['movies & directors']= df['original_title'] +'-'+ df['director']
x=df.groupby('movies & directors')['revenue'].mean().sort_values().tail(10)
x.plot(kind='barh',label='revenue',color='green',fontsize=12, figsize=(8,4),alpha=.4)
plt.title("Top 10 movies & directors",fontsize=20)
plt.xlabel("revenue")
plt.ylabel("movies & directors");
plt.legend();


# In[23]:


df2=df.nlargest(10, ['revenue'])


# In[24]:


data=df2[['revenue','genres']]
data


# In[25]:


plt.figure(figsize=(4.5,4.5))


df["revenue"] = pd.to_numeric(df["revenue"], downcast="float")

labels=['Action|Adventure|Fantasy|Science Fiction','Action|Adventure|Science Fiction|Fantasy',
                        'Drama|Romance|Thriller','Science Fiction|Action|Adventure',
                        'Action|Adventure|Science Fiction|Thriller','Action|Crime|Thriller','Action|Adventure|Science Fiction',
                        'Adventure|Family|Fantasy','Animation|Adventure|Family','Action|Adventure|Science Fiction']
values=[2781505847,2068178225,1845034188,1519557910,1513528810,1506249360,1405035767,1327817822,1274219009,1215439994]


plt.suptitle('Top 10 revenue by genres', fontsize=20)
plt.pie(values, labels=labels,radius=1,autopct='%0.2f%%',shadow=True,explode=[0.5,0,0,0,0,0,0,0,0,0],startangle=180)

plt.show()


# It seems that there is a co-relation between the investment budget of the industry of movies production and the revenue of it but not strong. Moreover, in the past twenty years, the analyses shown a huge leap in the film industry with profits reaching avarage more than 41 milion dollars, and that drive us to the pig quetion which is : What's make a movie sucess ? From data analysis, the top 10 films by earnings were genres most of them was Action,Adventures and Animation. In addition, fan reviews are actually more for this type of movie than in the past.
